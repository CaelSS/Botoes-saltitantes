package visao;

import javax.swing.JPanel;

public class teste extends JPanel {

	/**
	 * Create the panel.
	 */
	public teste() {

	}

}
