package visao;

import java.awt.Color;

import javax.swing.JPanel;

public class Painel extends JPanel {

	public Painel() {
		this.setSize(800, 600);
		this.setVisible(true);
		this.setBackground(Color.gray);
		this.setLayout(null);
	}
}
